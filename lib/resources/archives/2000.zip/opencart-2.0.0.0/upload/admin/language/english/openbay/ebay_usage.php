<?php
// Headings
$_['heading_title']             = 'Usage';
$_['text_openbay']              = 'OpenBay Pro';
$_['text_ebay']                 = 'eBay';

// Errors
$_['error_ajax_load']      		= 'Sorry, could not get a response. Try later.';